local ServerStorage = game:GetService("ServerStorage")

local EggSystem = {}
local eggFolder = ServerStorage:WaitForChild("Eggs")

function EggSystem.Spawn(eggName, position, variant)
    local template = eggFolder:FindFirstChild(eggName)
    if not template or not template:IsA("Model") then
        return nil, "Egg model not found in ServerStorage/Eggs"
    end

    local egg = template:Clone()
    egg:SetAttribute("Variant", variant or "Normal")
    egg:SetAttribute("CreatorPanelEgg", true)
    egg.Parent = workspace

    local spawnPosition = position or Vector3.new(0, 5, 0)
    egg:PivotTo(CFrame.new(spawnPosition))
    return egg
end

function EggSystem.RemoveLatest()
    local eggs = {}
    for _, item in ipairs(workspace:GetChildren()) do
        if item:GetAttribute("CreatorPanelEgg") then
            table.insert(eggs, item)
        end
    end
    local latest = eggs[#eggs]
    if latest then
        latest:Destroy()
        return true
    end
    return false
end

function EggSystem.SetLuck(amount)
    workspace:SetAttribute("EggLuck", amount)
end

return EggSystem
