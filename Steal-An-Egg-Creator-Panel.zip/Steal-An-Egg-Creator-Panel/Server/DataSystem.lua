local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")

local DataSystem = {}
local dataStore

function DataSystem.Init(storeName)
    dataStore = DataStoreService:GetDataStore(storeName)
end

function DataSystem.SavePlayer(player)
    if not dataStore or not player then
        return false, "DataStore not initialized or player missing"
    end

    local leaderstats = player:FindFirstChild("leaderstats")
    local coins = leaderstats and leaderstats:FindFirstChild("Coins")
    local payload = {
        Coins = coins and coins.Value or 0,
        SavedAt = os.time(),
    }

    local ok, err = pcall(function()
        dataStore:SetAsync("Player_" .. player.UserId, payload)
    end)
    return ok, err
end

function DataSystem.LoadPlayer(player)
    if not dataStore or not player then return nil end
    local ok, result = pcall(function()
        return dataStore:GetAsync("Player_" .. player.UserId)
    end)
    if ok then return result end
    warn("Could not load player data:", result)
    return nil
end

return DataSystem
