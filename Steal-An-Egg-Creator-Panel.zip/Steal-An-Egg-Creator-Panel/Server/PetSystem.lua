local ServerStorage = game:GetService("ServerStorage")

local PetSystem = {}
local petFolder = ServerStorage:WaitForChild("Pets")

function PetSystem.Spawn(petName, position, rarity)
    local template = petFolder:FindFirstChild(petName)
    if not template or not template:IsA("Model") then
        return nil, "Pet model not found in ServerStorage/Pets"
    end

    local pet = template:Clone()
    pet:SetAttribute("Rarity", rarity or "Normal")
    pet:SetAttribute("PetSpeed", 16)
    pet:SetAttribute("UpgradeLevel", 1)
    pet:SetAttribute("CreatorPanelPet", true)
    pet.Parent = workspace
    pet:PivotTo(CFrame.new(position or Vector3.new(0, 5, 0)))
    return pet
end

function PetSystem.RemoveLatest()
    local pets = {}
    for _, item in ipairs(workspace:GetChildren()) do
        if item:GetAttribute("CreatorPanelPet") then
            table.insert(pets, item)
        end
    end
    local latest = pets[#pets]
    if latest then
        latest:Destroy()
        return true
    end
    return false
end

function PetSystem.SetLatestSpeed(speed)
    for _, item in ipairs(workspace:GetChildren()) do
        if item:GetAttribute("CreatorPanelPet") then
            item:SetAttribute("PetSpeed", speed)
        end
    end
end

function PetSystem.UpgradeLatest(levels)
    for _, item in ipairs(workspace:GetChildren()) do
        if item:GetAttribute("CreatorPanelPet") then
            item:SetAttribute("UpgradeLevel", levels)
        end
    end
end

return PetSystem
