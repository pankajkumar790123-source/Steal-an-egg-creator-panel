local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")

local root = script.Parent
local Config = require(root:WaitForChild("Config"))
local Systems = root:WaitForChild("Systems")
local EggSystem = require(Systems:WaitForChild("EggSystem"))
local PetSystem = require(Systems:WaitForChild("PetSystem"))
local DataSystem = require(Systems:WaitForChild("DataSystem"))

DataSystem.Init(Config.PLAYER_DATA_STORE_NAME)

local remote = ReplicatedStorage:FindFirstChild("CreatorPanelCommand")
if not remote then
    remote = Instance.new("RemoteEvent")
    remote.Name = "CreatorPanelCommand"
    remote.Parent = ReplicatedStorage
end

local admins = table.clone(Config.ADMIN_USER_IDS)
local banStore = DataStoreService:GetDataStore(Config.BAN_STORE_NAME)

local function isAdmin(player)
    return admins[player.UserId] == true
end

local function getPlayer(name)
    if typeof(name) ~= "string" then return nil end
    local lowered = string.lower(name)
    for _, candidate in ipairs(Players:GetPlayers()) do
        if string.lower(candidate.Name) == lowered
            or string.lower(candidate.DisplayName) == lowered then
            return candidate
        end
    end
    return nil
end

local function getHumanoid(player)
    local character = player and player.Character
    return character and character:FindFirstChildOfClass("Humanoid")
end

local function getCoins(player)
    local stats = player:FindFirstChild("leaderstats")
    return stats and stats:FindFirstChild("Coins")
end

local function setupPlayer(player)
    local saved = DataSystem.LoadPlayer(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    local coins = Instance.new("IntValue")
    coins.Name = "Coins"
    coins.Value = (saved and tonumber(saved.Coins)) or 0
    coins.Parent = leaderstats
end

Players.PlayerAdded:Connect(function(player)
    local ok, banInfo = pcall(function()
        return banStore:GetAsync("User_" .. player.UserId)
    end)
    if ok and banInfo then
        player:Kick("You are banned from this experience.")
        return
    end
    setupPlayer(player)
end)

Players.PlayerRemoving:Connect(function(player)
    DataSystem.SavePlayer(player)
end)

local function announce(message)
    ReplicatedStorage:SetAttribute("CreatorPanelAnnouncement", message)
    print("[ANNOUNCEMENT] " .. message)
end

remote.OnServerEvent:Connect(function(admin, command, args)
    if not isAdmin(admin) then
        warn("Blocked unauthorized CreatorPanel request from", admin.Name)
        return
    end
    if typeof(command) ~= "string" or typeof(args) ~= "table" then return end

    local a = args
    local target = getPlayer(a.target)
    local amount = tonumber(a.amount)

    if command == "egg" then
        local variant = a.variant or "Normal"
        EggSystem.Spawn(a.name, admin.Character and admin.Character:GetPivot().Position + Vector3.new(0, 0, -8), variant)

    elseif command == "removeegg" then
        EggSystem.RemoveLatest()

    elseif command == "luck" then
        if amount then
            workspace:SetAttribute("EggLuck", math.clamp(amount, 1, Config.MAX_EGG_LUCK))
        end

    elseif command == "pet" then
        local rarity = a.rarity or "Normal"
        PetSystem.Spawn(a.name, admin.Character and admin.Character:GetPivot().Position + Vector3.new(4, 0, -8), rarity)

    elseif command == "removepet" then
        PetSystem.RemoveLatest()

    elseif command == "petspeed" then
        if amount then PetSystem.SetLatestSpeed(math.clamp(amount, 1, Config.MAX_PET_SPEED)) end

    elseif command == "petupgrade" then
        if amount then PetSystem.UpgradeLatest(math.clamp(amount, 1, 100)) end

    elseif command == "speed" then
        local humanoid = getHumanoid(target)
        if humanoid and amount then humanoid.WalkSpeed = math.clamp(amount, 0, Config.MAX_WALK_SPEED) end

    elseif command == "jump" then
        local humanoid = getHumanoid(target)
        if humanoid and amount then
            humanoid.UseJumpPower = true
            humanoid.JumpPower = math.clamp(amount, 0, Config.MAX_JUMP_POWER)
        end

    elseif command == "freeze" then
        local humanoid = getHumanoid(target)
        if humanoid then humanoid.WalkSpeed = 0; humanoid.JumpPower = 0 end

    elseif command == "unfreeze" then
        local humanoid = getHumanoid(target)
        if humanoid then humanoid.WalkSpeed = 16; humanoid.JumpPower = 50 end

    elseif command == "tp" then
        if target and admin.Character and target.Character then
            target.Character:PivotTo(admin.Character:GetPivot() * CFrame.new(3, 0, 0))
        end

    elseif command == "coins" or command == "reward" then
        local coins = getCoins(target)
        if coins and amount then
            coins.Value += math.clamp(amount, 0, Config.MAX_COIN_CHANGE)
        end

    elseif command == "takecoins" then
        local coins = getCoins(target)
        if coins and amount then
            coins.Value = math.max(0, coins.Value - math.clamp(amount, 0, Config.MAX_COIN_CHANGE))
        end

    elseif command == "setmoney" then
        local coins = getCoins(target)
        if coins and amount then
            coins.Value = math.clamp(amount, 0, Config.MAX_COIN_CHANGE)
        end

    elseif command == "kick" then
        if target then target:Kick(tostring(a.reason or "Removed by an administrator")) end

    elseif command == "ban" then
        if target then
            local ok, err = pcall(function()
                banStore:SetAsync("User_" .. target.UserId, {
                    Reason = tostring(a.reason or "Banned by an administrator"),
                    By = admin.UserId,
                    At = os.time(),
                })
            end)
            if ok then target:Kick("You are banned from this experience.")
            else warn("Ban save failed:", err) end
        end

    elseif command == "unban" then
        local userId = tonumber(a.userId)
        if userId then
            local ok, err = pcall(function()
                banStore:RemoveAsync("User_" .. userId)
            end)
            if not ok then warn("Unban failed:", err) end
        end

    elseif command == "addadmin" then
        local userId = tonumber(a.userId)
        if userId then admins[userId] = true end

    elseif command == "removeadmin" then
        local userId = tonumber(a.userId)
        if userId and userId ~= admin.UserId then admins[userId] = nil end

    elseif command == "autohatch" then
        workspace:SetAttribute("AutoHatchEnabled", a.enabled == true)

    elseif command == "doubleluck" then
        workspace:SetAttribute("DoubleLuckEnabled", a.enabled == true)

    elseif command == "timer" then
        if amount then workspace:SetAttribute("GameTimerSeconds", math.clamp(amount, 0, 86400)) end

    elseif command == "save" then
        if target then
            local ok, err = DataSystem.SavePlayer(target)
            if not ok then warn("Save failed:", err) end
        end

    elseif command == "announce" then
        if typeof(a.message) == "string" then
            announce(string.sub(a.message, 1, 180))
        end
    end
end)

print("Steal an Egg Creator Panel server ready.")
