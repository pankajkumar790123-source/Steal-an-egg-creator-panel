# Steal an Egg – Creator/Admin Panel (authorized games only)

This is a starter Roblox Studio project for a game you own or have explicit permission to edit.
It is **not** an executor, exploit, or script for controlling someone else's live game.

## What's included
- Egg spawning/removal and Golden, Diamond, Rainbow variants
- Egg luck setting
- Pet spawning/removal, Legendary/Secret variants, pet speed/upgrade attributes
- Walk speed, jump power, freeze/unfreeze, teleport
- Fly toggle (client-side helper; intended for your own game)
- Give/remove/set coins and rewards
- Kick, ban, unban, add/remove admin (admin list is in-memory except bans)
- Auto Hatch, Double Luck, game timer attribute
- Save Data (DataStore example)
- Server announcements
- Server-side admin permission checks and basic argument validation

## Important limitations
1. Roblox Studio is required to install and test server scripts. GitHub on Android can store/edit the files, but cannot publish them into a Roblox experience by itself.
2. The owner must add the scripts to their Studio project and configure the admin UserIds.
3. Add your egg and pet Models under `ServerStorage/Eggs` and `ServerStorage/Pets`. Models should have a PrimaryPart or be pivotable.
4. This is a starter framework. Adapt item names, economy rules, hatch logic, and DataStore schema to the actual game.
5. Ban storage uses DataStoreService. Enable **Game Settings → Security → Enable Studio Access to API Services** for Studio testing (prefer a separate test experience).
6. Never put passwords, API keys, or private credentials in this repository.

## Install in Roblox Studio
Create this structure:

- `ServerScriptService`
  - `CreatorPanel` (Folder)
    - `Config` (ModuleScript) ← paste `Server/Config.lua`
    - `Systems` (Folder)
      - `EggSystem` (ModuleScript) ← `Server/EggSystem.lua`
      - `PetSystem` (ModuleScript) ← `Server/PetSystem.lua`
      - `DataSystem` (ModuleScript) ← `Server/DataSystem.lua`
    - `AdminServer` (Script) ← `Server/AdminServer.server.lua`
- `StarterPlayer`
  - `StarterPlayerScripts`
    - `CreatorPanelClient` (LocalScript) ← `Client/CreatorPanel.client.lua`
- `ServerStorage`
  - `Eggs` (Folder; add your egg Models)
  - `Pets` (Folder; add your pet Models)

Set `Config.lua` `ADMIN_USER_IDS` to the trusted owner's/admins' numeric Roblox UserIds.
The client UI only sends requests. The server independently checks permissions before doing anything.

## Command examples
Enter these into the panel's command box:
- `egg BasicEgg`
- `egg GoldenEgg`
- `egg DiamondEgg`
- `egg RainbowEgg`
- `removeegg`
- `luck 5`
- `pet Dog`
- `petlegendary Dragon`
- `petsecret Phoenix`
- `removepet`
- `petspeed 30`
- `petupgrade 2`
- `speed PlayerName 32`
- `jump PlayerName 80`
- `freeze PlayerName`
- `unfreeze PlayerName`
- `tp PlayerName`
- `fly` (toggles fly for yourself)
- `coins PlayerName 500`
- `takecoins PlayerName 100`
- `setmoney PlayerName 1000`
- `reward PlayerName 250`
- `kick PlayerName reason`
- `ban PlayerName reason`
- `unban UserId`
- `addadmin UserId`
- `removeadmin UserId`
- `autohatch on`
- `autohatch off`
- `doubleluck on`
- `doubleluck off`
- `timer 120`
- `save PlayerName`
- `announce Hello players!`

Egg and pet names must match Models stored in the corresponding ServerStorage folder.
For `tp`, the target player is teleported to the admin running the command.
The `fly` command toggles a local fly helper for the admin running it.

## GitHub on Android
1. Open your repository in a browser.
2. Upload the ZIP contents or individual files using **Add file → Upload files**.
3. Keep this README so the project owner knows where each script belongs.
