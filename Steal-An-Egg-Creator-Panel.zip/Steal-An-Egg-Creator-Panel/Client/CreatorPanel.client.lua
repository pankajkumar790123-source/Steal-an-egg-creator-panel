-- Client UI for the authorized Creator Panel.
-- The server checks admin UserIds for every request.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local remote = ReplicatedStorage:WaitForChild("CreatorPanelCommand")

local gui = Instance.new("ScreenGui")
gui.Name = "StealEggCreatorPanel"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.fromOffset(330, 390)
frame.Position = UDim2.new(0.5, -165, 0.5, -195)
frame.BackgroundColor3 = Color3.fromRGB(22, 22, 32)
frame.BorderSizePixel = 0
frame.Parent = gui

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, 0, 0, 42)
title.BackgroundColor3 = Color3.fromRGB(95, 55, 160)
title.TextColor3 = Color3.new(1, 1, 1)
title.Text = "STEAL AN EGG • CREATOR"
title.TextScaled = true
title.Font = Enum.Font.GothamBold
title.Parent = frame

local commandBox = Instance.new("TextBox")
commandBox.Position = UDim2.fromOffset(10, 55)
commandBox.Size = UDim2.new(1, -20, 0, 42)
commandBox.PlaceholderText = "Example: egg BasicEgg"
commandBox.Text = ""
commandBox.ClearTextOnFocus = false
commandBox.TextScaled = true
commandBox.Parent = frame

local status = Instance.new("TextLabel")
status.Position = UDim2.fromOffset(10, 101)
status.Size = UDim2.new(1, -20, 0, 28)
status.BackgroundTransparency = 1
status.TextColor3 = Color3.fromRGB(220, 220, 220)
status.Text = "Commands are checked by the server."
status.TextScaled = true
status.Parent = frame

local function send(command, args)
    remote:FireServer(command, args)
    status.Text = "Request sent: " .. command
end

local function parseAndSend(raw)
    local parts = string.split(raw, " ")
    local cmd = string.lower(parts[1] or "")
    local args = {}

    if cmd == "egg" then
        args.name = parts[2] or "BasicEgg"
        args.variant = parts[3] or "Normal"
        send("egg", args)
    elseif cmd == "pet" or cmd == "petlegendary" or cmd == "petsecret" then
        args.name = parts[2] or "Dog"
        args.rarity = cmd == "petlegendary" and "Legendary"
            or (cmd == "petsecret" and "Secret" or "Normal")
        send("pet", args)
    elseif cmd == "removeegg" or cmd == "removepet" then
        send(cmd, args)
    elseif cmd == "luck" or cmd == "petspeed" or cmd == "petupgrade" or cmd == "timer" then
        args.amount = tonumber(parts[2])
        send(cmd, args)
    elseif cmd == "speed" or cmd == "jump" or cmd == "coins"
        or cmd == "takecoins" or cmd == "setmoney" or cmd == "reward" then
        args.target = parts[2]
        args.amount = tonumber(parts[3])
        send(cmd, args)
    elseif cmd == "freeze" or cmd == "unfreeze" or cmd == "tp"
        or cmd == "kick" or cmd == "ban" or cmd == "save" then
        args.target = parts[2]
        args.reason = table.concat(parts, " ", 3)
        send(cmd, args)
    elseif cmd == "unban" or cmd == "addadmin" or cmd == "removeadmin" then
        args.userId = tonumber(parts[2])
        send(cmd, args)
    elseif cmd == "autohatch" or cmd == "doubleluck" then
        args.enabled = string.lower(parts[2] or "") == "on"
        send(cmd, args)
    elseif cmd == "announce" then
        args.message = string.sub(raw, 10)
        send(cmd, args)
    elseif cmd == "fly" then
        player:SetAttribute("CreatorPanelFlyRequested", true)
        status.Text = "Fly helper is not included in this starter build."
    else
        status.Text = "Unknown command. Check README.md."
    end
end

local runButton = Instance.new("TextButton")
runButton.Position = UDim2.fromOffset(10, 138)
runButton.Size = UDim2.new(1, -20, 0, 38)
runButton.Text = "RUN COMMAND"
runButton.TextScaled = true
runButton.BackgroundColor3 = Color3.fromRGB(90, 55, 145)
runButton.TextColor3 = Color3.new(1, 1, 1)
runButton.Parent = frame
runButton.Activated:Connect(function()
    parseAndSend(commandBox.Text)
end)

local commands = {
    "egg BasicEgg", "egg GoldenEgg Golden", "egg DiamondEgg Diamond",
    "egg RainbowEgg Rainbow", "removeegg", "luck 5",
    "pet Dog", "petlegendary Dragon", "petsecret Phoenix", "removepet",
    "petspeed 30", "petupgrade 2", "speed PlayerName 32",
    "jump PlayerName 80", "freeze PlayerName", "unfreeze PlayerName",
    "tp PlayerName", "coins PlayerName 500", "takecoins PlayerName 100",
    "setmoney PlayerName 1000", "reward PlayerName 250",
    "kick PlayerName reason", "ban PlayerName reason", "unban 123456",
    "addadmin 123456", "removeadmin 123456", "autohatch on",
    "doubleluck on", "timer 120", "save PlayerName", "announce Hello!"
}

local list = Instance.new("ScrollingFrame")
list.Position = UDim2.fromOffset(10, 185)
list.Size = UDim2.new(1, -20, 1, -195)
list.BackgroundColor3 = Color3.fromRGB(32, 32, 44)
list.BorderSizePixel = 0
list.ScrollBarThickness = 6
list.CanvasSize = UDim2.fromOffset(0, #commands * 30)
list.Parent = frame

local layout = Instance.new("UIListLayout")
layout.Padding = UDim.new(0, 3)
layout.Parent = list

for _, command in ipairs(commands) do
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(1, -8, 0, 27)
    button.BackgroundColor3 = Color3.fromRGB(53, 53, 70)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Text = command
    button.TextScaled = true
    button.Parent = list
    button.Activated:Connect(function()
        commandBox.Text = command
    end)
end

-- Drag panel on touch or mouse using the title bar.
local dragging, dragStart, startPosition
title.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPosition = frame.Position
    end
end)
title.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
        dragging = false
    end
end)
UserInputService.InputChanged:Connect(function(input)
    if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch) then
        local delta = input.Position - dragStart
        frame.Position = UDim2.new(
            startPosition.X.Scale, startPosition.X.Offset + delta.X,
            startPosition.Y.Scale, startPosition.Y.Offset + delta.Y
        )
    end
end)
